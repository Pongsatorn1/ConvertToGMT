﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ConvertToGMT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DateTime result = DateTime.Now;
        String thGMT;

        private void Form1_Load(object sender, EventArgs e)
        {
            thGMT = string.Format("{0:d/M/yyyy HH:mm:ss}", result);
            label1.Text = thGMT.Substring(thGMT.Length - 8);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rb1.Checked == true || rb2.Checked == true || rb3.Checked == true || rb4.Checked == true)
            {
                label2.Text = thGMT.Substring(thGMT.Length - 8);
            }
            else if (rb5.Checked == true)
            {
                changetime_MM(thGMT);
            }
            else
            {
                changetime(thGMT);
            }
        }

        private void changetime(string Te)
        {
            var Values = Te.Substring(Te.Length - 8);
            string[] ResultT = Values.Split(new string[] { ":" }, StringSplitOptions.None);
            int r1 = Convert.ToInt32(ResultT[0]) + 1;
            label2.Text = r1.ToString() + ":" + ResultT[1] + ":" + ResultT[2];
        }

        private void changetime_MM(string p)
        {
            var t2 = 0;
            var t1 = 0;
            
            var Values = p.Substring(p.Length - 8);
            string[] ResultT = Values.Split(new string[] { ":" }, StringSplitOptions.None);
            int cvResult1 = Convert.ToInt32(ResultT[0].ToString());
            int cvResult2 = Convert.ToInt32(ResultT[1].ToString());

            if (cvResult2 > 30 && cvResult1>1)
            {
                t1 = cvResult1 - 1;
                t2=cvResult2 - 30;
            }
            if (cvResult2 < 30)
            {
                t1 = cvResult1 - 1;
                t2 = cvResult2 + 30;
            }

            label2.Text = t1.ToString()+":"+t2.ToString()+":"+ResultT[2].ToString() ;
           
        }

       

    }
}
